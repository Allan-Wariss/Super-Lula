import glfw
from OpenGL.GL import *
from shipObject import *
from texture import *

ship = ShipObject()

# Função que define configurações iniciais
def init():
    glClearColor(0,0,0,1.0)
    glEnable(GL_TEXTURE_2D)                       # Habilita textura na openGL
    
    tex = Texture('textures/ship.png')
    ship.texId = tex.texId

# Atualiza a lógica do seu jogo
def update():
    pass

# Função que atualiza a renderização da cena
def render():
    glClear(GL_COLOR_BUFFER_BIT)
    ship.draw()

# Função Principal
def main():
    glfw.init()
    window = glfw.create_window(700,700,'Jogo da Navinha',None,None)
    glfw.make_context_current(window)
    
    init() 

    while not glfw.window_should_close(window):
        glfw.poll_events()
        update()
        render()
        glfw.swap_buffers(window)

    glfw.terminate()

if __name__ == '__main__':
    main()           