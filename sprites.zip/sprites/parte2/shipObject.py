from OpenGL.GL import *

class ShipObject:
    def __init__(self):
        self.vertices = [
            [-0.5, -0.5],  # v0
            [0.5, -0.5],   # v1
            [0.5, 0.5],    # v2
            [-0.5, 0.5]    # v3
        ]
        
        # mapeamento de textura
        # coodenadas da textura - padrão openGL
        self.uvs = [
            [0, 0],
            [1, 0],
            [1, 1],
            [0, 1]
        ]

        self.faces = [
            [0, 1, 2],
            [0, 2, 3]
        ]
        
        self.texId = 0               # cria o objeto sem nenhuma textura
        self.color = [1, 1, 0]

    def draw(self):
        glColor3fv(self.color)
        glBindTexture(GL_TEXTURE_2D, self.texId) # qual textura aplicar
        
        glBegin(GL_TRIANGLES)

        for f in self.faces:
            for vid in f:
                glTexCoord2fv(self.uvs[vid]) # coord de textura
                glVertex2fv(self.vertices[vid])

        glEnd()
        
        glBindTexture(GL_TEXTURE_2D, 0) # desativa